import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: const Color(0xff9ac8ef),
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: const Text("Student Profile Card"),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 75,
                backgroundImage: AssetImage("assets/student.jpeg"),
              ),
              const SizedBox(height: 20),
              const Text(
                "Vajrapu Harshini",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "24PA1A05N5",
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 5),
              const Text(
                "CSE",
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 5),
              Container(
                width: 300,
                color: Colors.white,
                child: const ListTile(
                  leading: Icon(
                    Icons.phone,
                    color: Colors.blue,
                  ),
                  title: Text("+91 9876543210"),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 300,
                color: Colors.white,
                child: const ListTile(
                  leading: Icon(
                    Icons.email,
                    color: Colors.blue,
                  ),
                  title: Text("harshinivajrapu@gmail.com"),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
